const char* logl_root = "D:/school/CS 330 computational graphics/LearnOpenGL";
